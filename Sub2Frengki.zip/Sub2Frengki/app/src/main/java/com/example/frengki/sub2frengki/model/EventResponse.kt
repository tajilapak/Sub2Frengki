package com.example.frengki.sub2frengki.model

data class EventResponse (
        val events: List<Event>
)