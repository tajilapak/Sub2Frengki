package com.example.frengki.sub2frengki.model

data class TeamResponse (
        val teams: List<Team>
)