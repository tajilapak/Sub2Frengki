package com.example.frengki.sub2frengki.model

data class EventDetailResponse (
        val events: List<EventDetail>
)